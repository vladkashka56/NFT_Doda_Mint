<?php

$database_hostname = "localhost";
$database_username = "claytox5_doda";
$database_password = "dmO&Wap+Fs_%";
$database_name = "claytox5_doda";

$database_connection = new mysqli($database_hostname, $database_username, $database_password, $database_name);

$pdo = new PDO('mysql:host='.$database_hostname.';dbname='.$database_name,$database_username,$database_password); 

?>