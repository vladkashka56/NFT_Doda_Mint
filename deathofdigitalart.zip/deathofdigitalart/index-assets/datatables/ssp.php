<?php

// Require Config
require_once( dirname(__DIR__) . '/include/config.php' );
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
 
// DB table to use
$table = 'nft';
 
// Table's primary key
$primaryKey = 'id';
 
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
    array(
        'db'        => 'id',
        'dt'        => 0,
        'formatter' => function( $d, $row ) {
            return displayName($d);
        }
    ),
    array(
        'db'        => 'colors',
        'dt'        => 1,
        'formatter' => function( $d, $row ) {
            return displayColors($d);
        }
    )
);

// SQL server connection information
$sql_details = array(
    'user' => $database_username,
    'pass' => $database_password,
    'db'   => $database_name,
    'host' => $database_hostname
);

require( 'ssp.class.php' );
 
echo json_encode( SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns ) );



function displayName($get_id)
{
	$result = '<img src="/nft-images/'.$get_id.'.png" class="collection-image">Death of Digital Art &#35;'.$get_id;
	
	return $result;
}

function displayColors($get_colors)
{
	$current_colors = explode("|", $get_colors);
	
	$result = "";
	
	for($index = 0; $index < count($current_colors); $index++)
	{
		if($index != 0)
		{
			$result = $result . ", ";
		}
		$result = $result . "Pure " . $current_colors[$index];
	}
	
	return $result;
}