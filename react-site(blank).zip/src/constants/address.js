// export const contractAddress = "0x8C0181270C53ab6667C32ab0A3693E50FA342A24";
// export const chainId = 80001; //mumbai

export const contractAddress = "0xE4c02176761e37Bd06E4b2f744eCe84544a2092f";
export const chainId = 137; //polygon matic